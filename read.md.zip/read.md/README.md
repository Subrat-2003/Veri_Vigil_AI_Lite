# Veri-Vigil AI Lite  (v2.0 — Fixed)

A Chrome Extension + FastAPI backend that analyzes a YouTube video's title
and description and shows a real-time trust score overlay.

## What was fixed (v2.0)

| # | Bug | Fix |
|---|-----|-----|
| 1 | API key hardcoded in source (security risk) | Read from `OPENAI_API_KEY` env variable |
| 2 | `client.responses.create()` — method does not exist | Changed to `client.chat.completions.create()` |
| 3 | `response.output_text` — attribute does not exist | Changed to `response.choices[0].message.content` |
| 4 | No JSON-only instruction → `json.loads()` always crashed | Added system prompt forcing raw JSON output |

---

## Folder structure

```
veri-vigil-ai-lite/
├── backend/
│   ├── main.py
│   └── requirements.txt
├── extension/
│   ├── manifest.json
│   ├── content.js
│   ├── background.js
│   └── styles.css
└── README.md
```

---

## 1) Backend setup

Open a terminal inside the `backend/` folder.

```bash
python -m venv .venv
```

**Windows PowerShell**
```powershell
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

**Windows CMD**
```cmd
.venv\Scripts\activate.bat
pip install -r requirements.txt
```

**macOS / Linux**
```bash
source .venv/bin/activate
pip install -r requirements.txt
```

---

## 2) Set your OpenAI API key (required for AI analysis)

> ⚠️ IMPORTANT: Never put your API key directly in the source code.
> Always use an environment variable.

**Windows CMD** (set before running uvicorn, in the same terminal):
```cmd
set OPENAI_API_KEY=sk-your-key-here
set OPENAI_MODEL=gpt-4o-mini
uvicorn main:app --reload
```

**Windows PowerShell**:
```powershell
$env:OPENAI_API_KEY="sk-your-key-here"
$env:OPENAI_MODEL="gpt-4o-mini"
uvicorn main:app --reload
```

**macOS / Linux**:
```bash
export OPENAI_API_KEY=sk-your-key-here
export OPENAI_MODEL=gpt-4o-mini
uvicorn main:app --reload
```

If no key is set, the backend automatically falls back to the heuristic mock analyzer.

Backend runs at: http://127.0.0.1:8000

---

## 3) Load the Chrome extension

1. Open Chrome → `chrome://extensions/`
2. Enable **Developer mode** (top right toggle)
3. Click **Load unpacked**
4. Select the `extension/` folder
5. Open any YouTube video — the overlay appears automatically

---

## 4) How it works

```
YouTube page
    └─ content.js extracts title + description
         └─ POST /analyze  →  FastAPI backend
              ├─ analyze_with_openai()   ← tries AI first
              └─ analyze_with_mock()     ← fallback if no key / error
                   └─ returns { trust_score, status, explanation, source }
                        └─ overlay rendered on YouTube page
```

---

## 5) Example API call

```bash
curl -X POST http://127.0.0.1:8000/analyze \
  -H "Content-Type: application/json" \
  -d '{"title":"Secret cure they dont want you to know","description":"100% guaranteed miracle results. Must watch now."}'
```

**Response (mock)**:
```json
{
  "trust_score": 31,
  "status": "Suspicious",
  "explanation": "...",
  "source": "mock"
}
```

**Response (with OpenAI key set)**:
```json
{
  "trust_score": 18,
  "status": "Suspicious",
  "explanation": "This video uses multiple high-risk phrases...",
  "source": "openai"
}
```
