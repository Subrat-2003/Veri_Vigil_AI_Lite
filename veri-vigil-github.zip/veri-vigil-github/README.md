# Veri-Vigil AI Lite

A Chrome Extension + FastAPI backend that analyzes YouTube video titles and descriptions in real-time and shows a trust score overlay — on both regular videos and Shorts.

## Folder Structure

```
veri-vigil-ai-lite/
├── backend/
│   ├── main.py
│   └── requirements.txt
├── extension/
│   ├── manifest.json
│   ├── content.js
│   ├── background.js
│   └── styles.css
└── README.md
```

## Backend Setup

```cmd
cd backend
python -m venv venv311
venv311\Scripts\activate
pip install -r requirements.txt
```

## Get a Free Groq API Key

1. Go to https://console.groq.com
2. Sign up free
3. Click API Keys → Create API Key
4. Copy the key (starts with gsk_...)

## Run the Backend

```cmd
set GROQ_API_KEY=gsk_your_key_here
uvicorn main:app --reload --reload-dir .
```

Backend runs at: http://127.0.0.1:8000

## Load the Chrome Extension

1. Open Chrome → chrome://extensions/
2. Enable Developer mode
3. Click Load unpacked
4. Select the extension/ folder
5. Open any YouTube video or Short

## How It Works

- Extension extracts video title and description from the page
- Sends to FastAPI backend at POST /analyze
- Backend calls Groq AI (llama-3.1-8b-instant) for analysis
- Falls back to heuristic if Groq is unavailable
- Returns trust_score (0-100), status (Safe/Suspicious), explanation
- Overlay displayed on YouTube page

## Tech Stack

- FastAPI (Python backend)
- Groq AI — llama-3.1-8b-instant (free tier, 14400 req/day)
- Chrome Extension (Manifest V3)
- Vanilla JS content script
